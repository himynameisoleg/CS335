#!/usr/bin/env python3
# # -*- coding: utf-8 -*-
""" Beyond Search Homework """
__author__="Oleg Perchyk"

import random
import sys

def generate_random_board():
    return[random.randrange(0, 8, 1) for i in range(8)]

def hill_climbing_random(board):
    random_neighbor = generate_random_board()
    best_board = hill_climbing(board)
    cost = 0
    solved = 0
    

    while number_attacking(best_board) > 2: 
        random = hill_climbing(random_neighbor)
        if number_attacking(random_neighbor) < number_attacking(best_board):
            best_board = random
        random_neighbor = generate_random_board()
        cost += 1
        if number_attacking(best_board) == 0:
            solved += 1
        

    return { 
        "cost": cost,
        "solved": solved 
        }


def hill_climbing(board):
    current = board

    while True:    
        neighbor = get_neighbor(board)

        if number_attacking(neighbor) >= number_attacking(current):
            return current
        
        current = neighbor

def get_neighbor(board):
    board[random.randint(0,7)] = random.randint(0, 7)
    return board

def number_attacking(board):
    attacking = 0

    # horizontally
    for col in range(len(board)):
        queen_pos = board[col]
        for row in range(col + 1, len(board)):
            if board[row] == queen_pos:
                attacking += 1
    
    # vertically: based on hw specs we should not see any vertical attacks since we use 1D list representation

    # diagonally
    for col in range(len(board)):
        queen_pos = board[col]
        for row in range(col + 1, len(board)):
            if board[row] == queen_pos + (row - col):
                attacking += 1
            if board[row] == queen_pos - (row - col):
                attacking += 1

    return attacking


def main():
    num_puzzles = int(sys.argv[1])
    hc_cost = 0
    hc_solved = 0

    for i in range(num_puzzles):
        board = generate_random_board()
        hc = hill_climbing_random(board)
        hc_cost = hc["cost"]
        hc_solved = hc["solved"]


    print(f"Hill-climbing: {hc_solved / num_puzzles}% solved, average cost: {hc_cost / num_puzzles}")

if __name__ == "__main__":
    main()